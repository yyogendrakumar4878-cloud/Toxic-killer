# TOXIC KILLER
Android-first esports tournament app starter.

See `SETUP.md` for Supabase and Android build steps. This project is a starter foundation, not a production-ready APK.