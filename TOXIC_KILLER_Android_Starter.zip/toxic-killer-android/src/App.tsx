import { useEffect, useState } from 'react'
import { Shield, Trophy, Users, Wallet, Bell, LogOut, Crosshair, Flame, Menu, X, PlusCircle, RefreshCw } from 'lucide-react'
import { supabase, isSupabaseConfigured } from './lib/supabase'
import type { Profile, Tournament } from './types'

type Tab = 'home' | 'tournaments' | 'my-matches' | 'profile' | 'admin'

const demoTournaments: Tournament[] = [
  { id: 'demo-1', title: 'TOXIC NIGHT CLASH', game_mode: 'SQUAD', map_name: 'Bermuda', entry_fee: 0, prize_pool: 500, starts_at: new Date(Date.now()+86400000).toISOString(), max_players: 48, status: 'UPCOMING', description: 'Open community room. Demo preview only.' },
  { id: 'demo-2', title: 'RED ZONE DUO CUP', game_mode: 'DUO', map_name: 'Purgatory', entry_fee: 0, prize_pool: 250, starts_at: new Date(Date.now()+172800000).toISOString(), max_players: 24, status: 'UPCOMING', description: 'Demo preview only.' },
  { id: 'demo-3', title: 'SOLO ELIMINATION', game_mode: 'SOLO', map_name: 'Bermuda', entry_fee: 0, prize_pool: 100, starts_at: new Date(Date.now()+259200000).toISOString(), max_players: 48, status: 'UPCOMING', description: 'Demo preview only.' }
]

export default function App() {
  const [tab, setTab] = useState<Tab>('home')
  const [tournaments, setTournaments] = useState<Tournament[]>(demoTournaments)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')
  const [showAuth, setShowAuth] = useState(false)
  const [showCreate, setShowCreate] = useState(false)

  async function loadData() {
    if (!supabase) return
    const { data: auth } = await supabase.auth.getUser()
    if (auth.user) {
      const { data } = await supabase.from('profiles').select('id,username,ff_uid,ff_ign,role').eq('id', auth.user.id).maybeSingle()
      if (data) setProfile(data as Profile)
    } else setProfile(null)
    const { data: rows, error } = await supabase.from('tournaments').select('*').order('starts_at')
    if (!error && rows) setTournaments(rows as Tournament[])
  }

  useEffect(() => {
    void loadData()
    if (!supabase) return
    const { data: listener } = supabase.auth.onAuthStateChange(() => { void loadData() })
    return () => listener.subscription.unsubscribe()
  }, [])

  async function signIn(e: React.FormEvent) {
    e.preventDefault()
    if (!supabase) { setMessage('Connect Supabase first. See SETUP.md.'); return }
    setBusy(true); setMessage('')
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    setBusy(false)
    setMessage(error?.message ?? 'Signed in successfully.')
    if (!error) { setShowAuth(false); await loadData() }
  }
  async function signUp(e: React.FormEvent) {
    e.preventDefault()
    if (!supabase) { setMessage('Connect Supabase first. See SETUP.md.'); return }
    setBusy(true); setMessage('')
    const { error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin } })
    setBusy(false)
    setMessage(error?.message ?? 'Account created. Check your email to verify it.')
  }
  async function joinTournament(id: string) {
    if (!supabase) { setMessage('Demo preview: connect Supabase to register for real tournaments.'); return }
    if (!profile) { setShowAuth(true); setMessage('Please sign in before joining.'); return }
    const { error } = await supabase.from('registrations').insert({ tournament_id: id, user_id: profile.id })
    setMessage(error ? error.message : 'Registration submitted. Check My Matches for status.')
  }
  async function createTournament(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    if (!supabase || profile?.role !== 'ADMIN') { setMessage('Admin access required.'); return }
    const f = new FormData(e.currentTarget)
    const { error } = await supabase.from('tournaments').insert({
      title: String(f.get('title')), game_mode: String(f.get('mode')), map_name: String(f.get('map')),
      entry_fee: 0, prize_pool: Number(f.get('prize')), starts_at: new Date(String(f.get('starts'))).toISOString(),
      max_players: Number(f.get('max')), status: 'UPCOMING', description: String(f.get('description') || '')
    })
    setMessage(error?.message ?? 'Tournament created.')
    if (!error) { setShowCreate(false); await loadData() }
  }
  async function signOut() {
    await supabase?.auth.signOut()
    setProfile(null); setTab('home')
  }

  const upcoming = tournaments.filter(t => t.status === 'UPCOMING')
  const live = tournaments.filter(t => t.status === 'LIVE')
  const active = tab === 'tournaments' ? tournaments : tab === 'home' ? [...live, ...upcoming].slice(0, 3) : []

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand"><div className="brand-mark"><Flame size={22}/></div><div><b>TOXIC <span>KILLER</span></b><small>ESPORTS ARENA</small></div></div>
      <button className="icon-btn" onClick={() => setShowAuth(v => !v)} aria-label="Account">{profile ? <Shield/> : <Users/>}</button>
    </header>
    <main>
      <section className="hero">
        <div className="hero-glow"></div><div className="eyebrow"><span className="live-dot"></span> NEXT LEVEL BATTLE ARENA</div>
        <h1>ENTER THE<br/><em>BATTLE.</em></h1>
        <p>Compete. Dominate. Become the champion.</p>
        <div className="hero-actions"><button className="primary" onClick={() => setTab('tournaments')}>EXPLORE MATCHES <Crosshair size={16}/></button><button className="secondary" onClick={() => setShowAuth(true)}>JOIN NOW</button></div>
        <div className="hero-stats"><div><b>{tournaments.length.toString().padStart(2,'0')}</b><small>TOURNAMENTS</small></div><div><b>{live.length.toString().padStart(2,'0')}</b><small>LIVE NOW</small></div><div><b>24/7</b><small>COMMUNITY</small></div></div>
      </section>

      <div className="section-head"><div><small className="eyebrow">COMPETE FOR GLORY</small><h2>{tab === 'tournaments' ? 'ALL TOURNAMENTS' : tab === 'my-matches' ? 'MY MATCHES' : tab === 'profile' ? 'PLAYER PROFILE' : tab === 'admin' ? 'ADMIN CONTROL' : 'FEATURED MATCHES'}</h2></div><span className="section-icon"><Trophy/></span></div>

      {tab === 'profile' ? <section className="panel">
        {profile ? <><div className="profile-row"><div className="avatar">{(profile.username || profile.id).slice(0,1).toUpperCase()}</div><div><b>{profile.username || 'Player'}</b><small>{profile.role} ACCOUNT</small></div></div><p>Free Fire UID: {profile.ff_uid || 'Not added'}</p><p>In-game name: {profile.ff_ign || 'Not added'}</p><button className="secondary wide" onClick={signOut}><LogOut size={16}/> SIGN OUT</button></> : <><p>Sign in to view your player profile.</p><button className="primary wide" onClick={() => setShowAuth(true)}>SIGN IN / CREATE ACCOUNT</button></>}
      </section> : tab === 'my-matches' ? <section className="panel"><p>Sign in to see your tournament registrations and match history.</p>{profile && <MyMatches userId={profile.id}/>}</section> : tab === 'admin' ? <section className="panel"><div className="panel-title">ADMIN TOOLS</div>{profile?.role === 'ADMIN' ? <><p>Create and manage tournaments. Admin role must be assigned securely in Supabase.</p><button className="primary wide" onClick={() => setShowCreate(true)}><PlusCircle size={16}/> CREATE TOURNAMENT</button></> : <p>Restricted area. Sign in with an approved admin account.</p>}</section> : <section className="matches">
        {active.length === 0 ? <div className="empty">No tournaments available right now.<br/>Check back soon.</div> : active.map(t => <article className="match-card" key={t.id}>
          <div className="match-top"><span className={t.status === 'LIVE' ? 'tag live' : 'tag'}>{t.status}</span><span className="mode">{t.game_mode}</span></div>
          <h3>{t.title}</h3><p className="mapline">{t.map_name} MAP <span>•</span> {new Date(t.starts_at).toLocaleString()}</p>
          <div className="match-info"><div><small>PRIZE POOL</small><b>₹{t.prize_pool}</b></div><div><small>ENTRY FEE</small><b>{t.entry_fee === 0 ? 'FREE' : `₹${t.entry_fee}`}</b></div><div><small>MAX PLAYERS</small><b>{t.max_players}</b></div></div>
          <button className="join-btn" onClick={() => void joinTournament(t.id)}>JOIN TOURNAMENT <span>↗</span></button>
        </article>)}
      </section>}
      {message && <div className="notice">{message}</div>}
      {isSupabaseConfigured ? <div className="connection"><span className="live-dot"></span> BACKEND CONFIGURED</div> : <div className="connection muted"><span></span> PREVIEW MODE · CONNECT BACKEND TO GO LIVE</div>}
    </main>

    <nav className="bottom-nav">
      <NavItem icon={<Flame/>} label="HOME" active={tab==='home'} onClick={() => setTab('home')}/>
      <NavItem icon={<Trophy/>} label="MATCHES" active={tab==='tournaments'} onClick={() => setTab('tournaments')}/>
      <NavItem icon={<Users/>} label="MY MATCHES" active={tab==='my-matches'} onClick={() => setTab('my-matches')}/>
      <NavItem icon={<Wallet/>} label="PROFILE" active={tab==='profile'} onClick={() => setTab('profile')}/>
      <NavItem icon={<Shield/>} label="ADMIN" active={tab==='admin'} onClick={() => setTab('admin')}/>
    </nav>

    {showAuth && <div className="modal-backdrop" onClick={() => setShowAuth(false)}><div className="modal" onClick={e => e.stopPropagation()}><div className="modal-head"><h3>PLAYER ACCESS</h3><button className="icon-btn" onClick={() => setShowAuth(false)}><X/></button></div><form onSubmit={signIn}><label>EMAIL</label><input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="player@email.com"/><label>PASSWORD</label><input type="password" required minLength={6} value={password} onChange={e => setPassword(e.target.value)} placeholder="At least 6 characters"/><button className="primary wide" disabled={busy}>{busy ? 'PLEASE WAIT…' : 'SIGN IN'}</button><button type="button" className="text-btn" disabled={busy} onClick={() => void signUp({ preventDefault: () => {} } as React.FormEvent)}>CREATE NEW ACCOUNT</button></form><p className="hint">Email verification may be required. Configure Supabase first.</p></div></div>}
    {showCreate && <div className="modal-backdrop" onClick={() => setShowCreate(false)}><div className="modal" onClick={e => e.stopPropagation()}><div className="modal-head"><h3>NEW TOURNAMENT</h3><button className="icon-btn" onClick={() => setShowCreate(false)}><X/></button></div><form onSubmit={e => void createTournament(e)}><label>TOURNAMENT NAME</label><input name="title" required placeholder="e.g. TOXIC NIGHT CUP"/><label>MODE</label><select name="mode"><option>SOLO</option><option>DUO</option><option>SQUAD</option></select><label>MAP</label><input name="map" required defaultValue="Bermuda"/><label>PRIZE POOL (₹)</label><input name="prize" type="number" min="0" required defaultValue="0"/><label>START TIME</label><input name="starts" type="datetime-local" required/><label>MAX PLAYERS</label><input name="max" type="number" min="2" required defaultValue="48"/><label>DESCRIPTION</label><input name="description" placeholder="Match rules and details"/><button className="primary wide">PUBLISH TOURNAMENT</button></form></div></div>}
  </div>
}

function NavItem({icon,label,active,onClick}:{icon:React.ReactNode,label:string,active:boolean,onClick:()=>void}) {
  return <button className={`nav-item ${active?'active':''}`} onClick={onClick}>{icon}<small>{label}</small></button>
}
function MyMatches({userId}:{userId:string}) {
  const [rows,setRows] = useState<any[]>([])
  useEffect(() => { if (!supabase) return; void supabase.from('registrations').select('id,status,created_at,tournaments(title,starts_at,game_mode)').eq('user_id',userId).order('created_at',{ascending:false}).then(({data})=>setRows(data||[])) },[userId])
  return <div>{rows.length ? rows.map(r=><div className="registration" key={r.id}><b>{r.tournaments?.title || 'Tournament'}</b><span>{r.status}</span></div>) : <p>No registrations yet.</p>}</div>
}