export type TournamentStatus = 'UPCOMING' | 'LIVE' | 'COMPLETED'
export type GameMode = 'SOLO' | 'DUO' | 'SQUAD'
export interface Tournament {
  id: string
  title: string
  game_mode: GameMode
  map_name: string
  entry_fee: number
  prize_pool: number
  starts_at: string
  max_players: number
  status: TournamentStatus
  description: string | null
}
export interface Profile {
  id: string
  username: string | null
  ff_uid: string | null
  ff_ign: string | null
  role: 'PLAYER' | 'ADMIN'
}