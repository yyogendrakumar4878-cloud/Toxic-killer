-- TOXIC KILLER initial schema. Run in Supabase SQL Editor.
-- Do not put the service_role key in the Android app.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  ff_uid text,
  ff_ign text,
  role text not null default 'PLAYER' check (role in ('PLAYER','ADMIN')),
  created_at timestamptz not null default now()
);

create table if not exists public.tournaments (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  game_mode text not null check (game_mode in ('SOLO','DUO','SQUAD')),
  map_name text not null,
  entry_fee numeric(10,2) not null default 0 check (entry_fee >= 0),
  prize_pool numeric(10,2) not null default 0 check (prize_pool >= 0),
  starts_at timestamptz not null,
  max_players integer not null check (max_players > 0),
  status text not null default 'UPCOMING' check (status in ('UPCOMING','LIVE','COMPLETED','CANCELLED')),
  description text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.registrations (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid not null references public.tournaments(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'PENDING' check (status in ('PENDING','APPROVED','REJECTED','CANCELLED')),
  created_at timestamptz not null default now(),
  unique(tournament_id,user_id)
);

-- Keep room credentials separate: never expose them through the public tournament list.
create table if not exists public.tournament_rooms (
  tournament_id uuid primary key references public.tournaments(id) on delete cascade,
  room_id text not null,
  room_password text not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.match_results (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid not null references public.tournaments(id) on delete cascade,
  winner_user_id uuid references public.profiles(id),
  winner_ign text not null,
  placement integer,
  kills integer not null default 0,
  proof_url text,
  verified_by uuid references public.profiles(id),
  verified_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  title text not null,
  body text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role = 'ADMIN');
$$;

alter table public.profiles enable row level security;
alter table public.tournaments enable row level security;
alter table public.registrations enable row level security;
alter table public.match_results enable row level security;
alter table public.tournament_rooms enable row level security;
alter table public.notifications enable row level security;

create policy "profiles readable by signed in users" on public.profiles
for select to authenticated using (true);
create policy "user can insert own profile" on public.profiles
for insert to authenticated with check (id = auth.uid() and role = 'PLAYER');
create policy "user can update own profile fields" on public.profiles
for update to authenticated using (id = auth.uid()) with check (id = auth.uid() and role = 'PLAYER');

create policy "tournaments readable" on public.tournaments
for select to anon, authenticated using (true);
create policy "admins manage tournaments" on public.tournaments
for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "users read own registrations or admins read all" on public.registrations
for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "users register themselves" on public.registrations
for insert to authenticated with check (user_id = auth.uid());
create policy "admins update registrations" on public.registrations
for update to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "approved players and admins can read room details" on public.tournament_rooms
for select to authenticated using (
  public.is_admin() or exists (
    select 1 from public.registrations r
    where r.tournament_id = tournament_rooms.tournament_id
      and r.user_id = auth.uid() and r.status = 'APPROVED'
  )
);
create policy "admins manage room details" on public.tournament_rooms
for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "results readable" on public.match_results
for select to anon, authenticated using (true);
create policy "admins manage results" on public.match_results
for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "users read own notifications" on public.notifications
for select to authenticated using (user_id is null or user_id = auth.uid());
create policy "users update own notifications" on public.notifications
for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Automatically create a PLAYER profile when a new auth user signs up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id, username) values (new.id, split_part(new.email, '@', 1));
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- IMPORTANT: after creating your own account, promote ONLY your own verified account:
-- update public.profiles set role='ADMIN' where id='YOUR_AUTH_USER_UUID';
-- Run this manually in SQL editor while logged in as project owner.
