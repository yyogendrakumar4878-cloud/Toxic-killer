import type { CapacitorConfig } from '@capacitor/cli'
const config: CapacitorConfig = {
  appId: 'com.toxickiller.tournament',
  appName: 'TOXIC KILLER',
  webDir: 'dist',
  bundledWebRuntime: false
}
export default config