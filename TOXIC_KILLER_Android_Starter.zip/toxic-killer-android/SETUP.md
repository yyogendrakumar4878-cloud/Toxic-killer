# TOXIC KILLER — Android starter

This is a React + Capacitor Android project with a Supabase-backed foundation.
The included screen can run in preview mode, but it is **not live** until you connect your own Supabase project and apply the SQL schema.

## Important security notes
- Never place a Supabase `service_role` key in this app. Use only the project's public anon/publishable key.
- Admin access is controlled by the `profiles.role` database field and RLS. Do not add a client-side "make me admin" button.
- Entry fee and wallet transfers are intentionally not enabled in this starter. Add a compliant payment provider and server-side verification before accepting money.
- Do not share your Supabase keys publicly or in chat.

## 1. Create the Supabase backend
1. Create a project at https://supabase.com.
2. Open SQL Editor and run `supabase/schema.sql`.
3. In Project Settings → API, copy Project URL and the anon/public key.
4. Copy `.env.example` to `.env` and fill:
   `VITE_SUPABASE_URL=...`
   `VITE_SUPABASE_ANON_KEY=...`
5. In Authentication settings, configure email confirmation and your allowed redirect URLs.

## 2. Build from an Android-only workflow
A phone can edit the project, but producing a signed Android APK from a full Capacitor project is easiest with a cloud build service or a computer with Android Studio.
1. Upload this ZIP to a private GitHub repository (do not upload `.env`).
2. Use a cloud development/build environment that supports Node.js and Android SDK, or open the repo on a computer with Android Studio.
3. Run:
   `npm install`
   `npm run build`
   `npx cap add android`
   `npx cap sync android`
4. Open the generated `android` project in Android Studio and build an APK.
5. For release distribution, create and securely back up your signing keystore. Never share the keystore or passwords.

## 3. Create your first admin
1. Sign up through the app after Supabase is connected.
2. In Supabase → Authentication → Users, find your account UUID.
3. In SQL Editor run:
   `update public.profiles set role='ADMIN' where id='YOUR_AUTH_USER_UUID';`
4. Sign out and sign in again.

## Current starter scope
- Dark black/red responsive gaming UI
- Supabase email sign-in and sign-up
- Tournament listing
- Player registration requests
- My Matches list
- Admin-only tournament creation
- Database tables and initial RLS policies

## Still to build before production
- Profile editing and Free Fire UID validation
- Admin approval/rejection workflow UI
- Room ID/password release rules (only approved players)
- Results submission and winner verification UI
- Push notifications
- Payment gateway, refunds, ledger and server-side payment verification
- Rate limiting, abuse protection, audit logs and production security review

## Known limitation
The first starter release is a foundation, not a finished production tournament platform. Do not accept entry fees or promise cash prizes until the rules, payments, age requirements, legal compliance, and backend verification are implemented and tested.
